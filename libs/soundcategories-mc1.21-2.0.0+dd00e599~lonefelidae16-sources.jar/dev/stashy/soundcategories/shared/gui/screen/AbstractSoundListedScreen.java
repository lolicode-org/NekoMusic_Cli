package dev.stashy.soundcategories.shared.gui.screen;

import dev.stashy.soundcategories.shared.SoundCategories;
import dev.stashy.soundcategories.shared.gui.widget.VersionedButtonWrapper;
import dev.stashy.soundcategories.shared.gui.widget.VersionedElementListWrapper;
import dev.stashy.soundcategories.shared.text.VersionedText;
import java.util.Arrays;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import net.minecraft.class_4667;

public abstract class AbstractSoundListedScreen extends class_4667 {
    protected VersionedElementListWrapper list;

    public AbstractSoundListedScreen(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    protected void addDoneButton() {
        addDoneButton(false);
    }

    protected void addDoneButton(boolean withCancel) {
        if (withCancel) {
            this.method_37063(
                    VersionedButtonWrapper.newInstance(
                            this.field_22789 / 2 - 155, this.field_22790 - 27, 150, 20,
                            VersionedText.INSTANCE.getDoneText(), (button) -> {
                                this.field_22787.field_1690.method_1640();
                                this.field_22787.method_1507(this.field_21335);
                            }
                    )
            );
            this.method_37063(
                    VersionedButtonWrapper.newInstance(
                            this.field_22789 / 2 - 155 + 160, this.field_22790 - 27, 150, 20,
                            VersionedText.INSTANCE.getCancelText(), (button) -> this.field_22787.method_1507(this.field_21335)
                    )
            );
        } else {
            this.method_37063(
                    VersionedButtonWrapper.newInstance(
                            this.field_22789 / 2 - 100, this.field_22790 - 27, 200, 20,
                            VersionedText.INSTANCE.getDoneText(), (button) -> {
                                this.field_22787.field_1690.method_1640();
                                this.field_22787.method_1507(this.field_21335);
                            }
                    )
            );
        }
    }

    @Override
    protected void method_25426() {
        this.list = VersionedElementListWrapper.newInstance(this.field_22787, this.field_22789, this.field_22790, 32, this.field_22790 - 32, 25);
        super.method_25426();

        this.method_37063(this.list);
    }

    protected class_3419[] filterByParentCategory(class_3419 parentCategory) {
        return Arrays.stream(class_3419.values()).filter(it -> {
            return SoundCategories.PARENTS.containsKey(it) && SoundCategories.PARENTS.get(it) == parentCategory;
        }).toArray(class_3419[]::new);
    }
}
