package dev.stashy.soundcategories.shared.gui.screen;

import dev.stashy.soundcategories.shared.SoundCategories;
import dev.stashy.soundcategories.shared.text.VersionedText;
import me.lonefelidae16.groominglib.api.McVersionInterchange;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.Objects;

@Environment(EnvType.CLIENT)
public abstract class VersionedSoundOptionsScreen extends AbstractSoundListedScreen {
    private static final String METHOD_KEY_INIT = VersionedSoundOptionsScreen.class.getCanonicalName() + "#<init>";

    static {
        try {
            Class<VersionedSoundOptionsScreen> clazz = McVersionInterchange.getCompatibleClass(SoundCategories.BASE_PACKAGE, "gui.screen.CustomSoundOptionsScreen");
            Constructor<VersionedSoundOptionsScreen> constructor = clazz.getConstructor(class_437.class, class_315.class);
            SoundCategories.CACHED_INIT_MAP.put(METHOD_KEY_INIT, Objects.requireNonNull(constructor));
        } catch (Exception ex) {
            SoundCategories.LOGGER.error("Failed to find 'CustomSoundOptionsScreen' class.", ex);
        }
    }

    public VersionedSoundOptionsScreen(class_437 parent, class_315 options) {
        super(parent, options, VersionedText.INSTANCE.translatable("options.sounds.title"));
    }

    public static VersionedSoundOptionsScreen newInstance(class_437 parent, class_315 settings) {
        try {
            Constructor<VersionedSoundOptionsScreen> constructor = (Constructor<VersionedSoundOptionsScreen>) SoundCategories.CACHED_INIT_MAP.get(METHOD_KEY_INIT);
            return constructor.newInstance(parent, settings);
        } catch (Exception ex) {
            SoundCategories.LOGGER.error("Cannot instantiate 'CustomSoundOptionsScreen'", ex);
        }
        return null;
    }

    protected abstract void initList();

    @Override
    protected void method_25426() {
        super.method_25426();

        try {
            Objects.requireNonNull(this.list);
        } catch (NullPointerException ex) {
            SoundCategories.LOGGER.error("Error during screen initialization", ex);
            return;
        }

        this.initList();
    }

    protected class_3419[] filterVanillaCategory() {
        return Arrays.stream(class_3419.values()).filter(it -> {
            return !SoundCategories.PARENTS.containsKey(it) &&
                    !SoundCategories.PARENTS.containsValue(it) &&
                    it != class_3419.field_15250;
        }).toArray(class_3419[]::new);
    }

    protected class_3419[] filterCustomizedMasterCategory() {
        return Arrays.stream(SoundCategories.MASTER_CLASSES).map(SoundCategories.MASTERS::get).toArray(class_3419[]::new);
    }
}
