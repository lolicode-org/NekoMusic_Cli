package dev.stashy.soundcategories.shared.gui.widget;

import dev.stashy.soundcategories.shared.SoundCategories;
import dev.stashy.soundcategories.shared.text.VersionedText;
import me.lonefelidae16.groominglib.api.McVersionInterchange;
import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_6379;
import java.lang.reflect.Method;
import java.util.Objects;

public interface VersionedButtonWrapper extends class_364, class_4068, class_6379 {
    String METHOD_KEY_INIT = VersionedButtonWrapper.class.getCanonicalName() + "#init";

    static VersionedButtonWrapper newInstance(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 callback) {
        return newInstance(x, y, width, height, message, callback, VersionedText.INSTANCE.empty());
    }

    static VersionedButtonWrapper newInstance(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 callback, class_2561 tooltipContent) {
        Method init = SoundCategories.CACHED_METHOD_MAP.getOrDefault(METHOD_KEY_INIT, null);

        if (init == null) {
            try {
                Class<VersionedButtonWrapper> clazz = McVersionInterchange.getCompatibleClass(SoundCategories.BASE_PACKAGE, "gui.widget.ButtonWidgetImpl");
                init = Objects.requireNonNull(clazz).getMethod("init", int.class, int.class, int.class, int.class, class_2561.class, class_4185.class_4241.class, class_2561.class);
                SoundCategories.CACHED_METHOD_MAP.put(METHOD_KEY_INIT, Objects.requireNonNull(init));
            } catch (Exception ex) {
                SoundCategories.LOGGER.error("Failed to init 'ButtonWidget' class.", ex);
            }
        }

        try {
            return (VersionedButtonWrapper) Objects.requireNonNull(init).invoke(null, x, y, width, height, message, callback, tooltipContent);
        } catch (Exception ex) {
            SoundCategories.LOGGER.error("Cannot instantiate 'ButtonWidget'", ex);
        }

        return null;
    }
}
