package dev.stashy.soundcategories.shared.gui.widget;

import dev.stashy.soundcategories.shared.SoundCategories;
import dev.stashy.soundcategories.shared.option.VersionedSimpleOptionProvider;
import me.lonefelidae16.groominglib.api.McVersionInterchange;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_339;
import net.minecraft.class_3419;
import net.minecraft.class_344;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_6379;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public interface VersionedElementListWrapper extends class_4068, class_364, class_6379 {
    String METHOD_KEY_INIT = VersionedElementListWrapper.class.getCanonicalName() + "#init";

    static VersionedElementListWrapper newInstance(class_310 client, int width, int height, int top, int bottom, int itemHeight) {
        Method init = SoundCategories.CACHED_METHOD_MAP.getOrDefault(METHOD_KEY_INIT, null);

        if (init == null) {
            try {
                Class<?> clazz = McVersionInterchange.getCompatibleClass(SoundCategories.BASE_PACKAGE, "gui.widget.SoundList");
                init = Objects.requireNonNull(clazz).getMethod("init", class_310.class, int.class, int.class, int.class, int.class, int.class);
                SoundCategories.CACHED_METHOD_MAP.put(METHOD_KEY_INIT, Objects.requireNonNull(init));
            } catch (Exception ex) {
                SoundCategories.LOGGER.error("Failed to init 'SoundList' class.", ex);
            }
        }

        try {
            return (VersionedElementListWrapper) Objects.requireNonNull(init).invoke(null, client, width, height, top, bottom, itemHeight);
        } catch (Exception ex) {
            SoundCategories.LOGGER.error("Cannot instantiate 'SoundList'", ex);
        }

        return null;
    }

    default int addSingleOptionEntry(Object option) {
        return this.addSingleOptionEntry(option, true);
    }

    int addSingleOptionEntry(Object option, boolean editable);

    int addOptionEntry(Object firstOption, @Nullable Object secondOption);

    default void addAll(Object[] options) {
        for (int i = 0; i < options.length; i += 2) {
            this.addOptionEntry(options[i], i < options.length - 1 ? options[i + 1] : null);
        }
    }

    int addCategory(class_3419 cat);

    int addReadOnlyCategory(class_3419 cat);

    void addAllCategory(class_3419[] categories);

    int addGroup(class_3419 group, class_4185.class_4241 pressAction);

    void setDimensionsImpl(int width, int height);

    boolean mouseScrolledImpl(double mouseX, double mouseY, double horizontalAmount, double verticalAmount);

    void addDrawable(class_339 button);

    @Environment(EnvType.CLIENT)
    abstract class VersionedSoundEntry extends class_4265.class_4266<VersionedSoundEntry> {
        private static final String METHOD_KEY_CONSTR = VersionedSoundEntry.class.getCanonicalName() + "#<init>";

        public List<? extends class_339> widgets;

        static {
            try {
                Class<VersionedSoundEntry> entry = McVersionInterchange.getCompatibleClass(SoundCategories.BASE_PACKAGE, "gui.widget.SoundEntry");
                Constructor<VersionedSoundEntry> constructor = entry.getConstructor(List.class);
                SoundCategories.CACHED_INIT_MAP.put(METHOD_KEY_CONSTR, Objects.requireNonNull(constructor));
            } catch (Exception ex) {
                SoundCategories.LOGGER.error("Failed to init 'SoundEntry' class.", ex);
            }
        }

        public VersionedSoundEntry(List<? extends class_339> w) {
            this.widgets = w;
        }

        public static VersionedSoundEntry newInstance(List<? extends class_339> w) {
            try {
                Constructor<VersionedSoundEntry> constructor = (Constructor<VersionedSoundEntry>) SoundCategories.CACHED_INIT_MAP.get(METHOD_KEY_CONSTR);
                return constructor.newInstance(w);
            } catch (Exception ex) {
                SoundCategories.LOGGER.error("Cannot instantiate 'SoundEntry'", ex);
            }
            return null;
        }

        public static VersionedSoundEntry create(class_315 options, int width, Object option) {
            return VersionedSoundEntry.newInstance(
                    List.of(Objects.requireNonNull(
                            VersionedSimpleOptionProvider.INSTANCE.createWidget(option, options, width / 2 - 155, 0, 310)
                    ))
            );
        }

        public static VersionedSoundEntry createDouble(class_315 options, int width, Object first, @Nullable Object second) {
            List<class_339> widgets = new ArrayList<>();
            widgets.add(VersionedSimpleOptionProvider.INSTANCE.createWidget(first, options, width / 2 - 155, 0, 150));
            if (second != null) {
                widgets.add(VersionedSimpleOptionProvider.INSTANCE.createWidget(second, options, width / 2 + 5, 0, 150));
            }
            return VersionedSoundEntry.newInstance(widgets);
        }

        public static VersionedSoundEntry createGroup(class_315 options, Object group, int width, class_4185.class_4241 pressAction) {
            return VersionedSoundEntry.newInstance(
                    List.of(
                            Objects.requireNonNull(VersionedSimpleOptionProvider.INSTANCE.createWidget(group, options, width / 2 - 155, 0, 280)),
                            (class_344) Objects.requireNonNull(
                                    VersionedTexturedButtonWrapper.newInstance(width / 2 + 135, 0, 20, 20, 0, 0, 20,
                                            20, 40, pressAction)
                            )
                    ));
        }

        public List<? extends class_364> method_25396() {
            return this.widgets;
        }

        public List<? extends class_6379> method_37025() {
            return this.widgets;
        }
    }
}
