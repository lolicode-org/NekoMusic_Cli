package dev.stashy.soundcategories.shared.option;

import dev.stashy.soundcategories.shared.SoundCategories;
import me.lonefelidae16.groominglib.api.McVersionInterchange;
import net.minecraft.class_315;
import net.minecraft.class_339;
import java.util.Objects;

public abstract class VersionedSimpleOptionProvider {
    public static final VersionedSimpleOptionProvider INSTANCE;

    static {
        VersionedSimpleOptionProvider instance = null;
        try {
            Class<VersionedSimpleOptionProvider> clazz = McVersionInterchange.getCompatibleClass(SoundCategories.BASE_PACKAGE, "option.SimpleOptionImpl");
            instance = clazz.getConstructor().newInstance();
        } catch (Exception ex) {
            SoundCategories.LOGGER.error("Failed to init 'OptionImpl' class.", ex);
        }
        INSTANCE = Objects.requireNonNull(instance);
    }

    public abstract class_339 createWidget(Object instance, class_315 options, int x, int y, int width);
}
