package dev.stashy.soundcategories.mc1_21.gui.screen;

import dev.stashy.soundcategories.shared.gui.screen.VersionedSoundOptionsScreen;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import net.minecraft.class_7172;

public class CustomSoundOptionsScreen extends VersionedSoundOptionsScreen {
    public CustomSoundOptionsScreen(class_437 parent, class_315 gameOptions) {
        super(parent, gameOptions);
    }

    @Override
    protected void initList() {
        this.list.addCategory(class_3419.field_15250);
        this.list.addAllCategory(this.filterVanillaCategory());
        this.list.addSingleOptionEntry(this.field_21336.method_42477());
        this.list.addAll(new class_7172<?>[]{this.field_21336.method_42443(), this.field_21336.method_42444()});

        for (class_3419 category : this.filterCustomizedMasterCategory()) {
            this.list.addGroup(category, button -> this.field_22787.method_1507(new SoundGroupOptionsScreen(this, this.field_21336, category)));
        }
    }

    @Override
    protected void method_60325() {
    }

    @Override
    protected void method_48640() {
        super.method_48640();
        this.list.setDimensionsImpl(this.field_22789, this.field_49503.method_57727());
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return this.list.mouseScrolledImpl(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
}
