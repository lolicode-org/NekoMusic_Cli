package dev.stashy.soundcategories.mc1_21.gui.screen;

import dev.stashy.soundcategories.shared.SoundCategories;
import dev.stashy.soundcategories.shared.gui.screen.AbstractSoundListedScreen;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_437;

public class SoundGroupOptionsScreen extends AbstractSoundListedScreen {
    private final class_3419 parentCategory;

    public SoundGroupOptionsScreen(class_437 parent, class_315 gameOptions, class_3419 category) {
        super(parent, gameOptions, class_2561.method_43471(SoundCategories.getOptionsTranslationKey(category)));
        this.parentCategory = category;
    }

    @Override
    protected void method_60325() {
        this.list.addReadOnlyCategory(this.parentCategory);
        this.list.addAllCategory(this.filterByParentCategory(this.parentCategory));
    }

    @Override
    protected void method_48640() {
        super.method_48640();
        this.list.setDimensionsImpl(this.field_22789, this.field_49503.method_57727());
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return this.list.mouseScrolledImpl(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
}
