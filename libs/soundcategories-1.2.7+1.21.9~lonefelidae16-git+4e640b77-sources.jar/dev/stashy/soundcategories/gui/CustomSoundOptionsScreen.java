package dev.stashy.soundcategories.gui;

import dev.stashy.soundcategories.SoundCategories;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import net.minecraft.class_7172;
import java.util.Arrays;
import java.util.Objects;

@Environment(EnvType.CLIENT)
public class CustomSoundOptionsScreen extends AbstractSoundListedScreen {
    public CustomSoundOptionsScreen(class_437 parent, class_315 options) {
        super(parent, options, class_2561.method_43471("options.sounds.title"));
    }

    @Override
    protected void method_60325() {

    }

    @Override
    protected void method_60329() {
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return this.list.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        try {
            Objects.requireNonNull(this.list);
        } catch (NullPointerException ex) {
            SoundCategories.LOGGER.error("Error during screen initialization", ex);
            return;
        }

        this.list.addCategory(class_3419.field_15250);
        class_3419[] cats = Arrays.stream(class_3419.values()).filter(it -> {
            return !SoundCategories.PARENTS.containsKey(it) &&
                    !SoundCategories.PARENTS.containsValue(it) &&
                    it != class_3419.field_15250;
        }).toArray(class_3419[]::new);
        this.list.addAllCategory(cats);
        this.list.addSingleOptionEntry(field_21336.method_42477());
        this.list.addAll(new class_7172[]{field_21336.method_42443(), field_21336.method_42444()});

        for (String key : SoundCategories.MASTER_CLASSES) {
            final class_3419 category = SoundCategories.MASTERS.get(key);
            this.list.addGroup(category, button -> this.field_22787.method_1507(new SoundGroupOptionsScreen(this, field_21336, category)));
        }

        this.method_37063(this.list);
    }
}
