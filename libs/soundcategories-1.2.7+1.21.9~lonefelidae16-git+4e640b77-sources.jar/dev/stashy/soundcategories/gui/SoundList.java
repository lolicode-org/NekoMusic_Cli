package dev.stashy.soundcategories.gui;

import dev.stashy.soundcategories.SoundCategories;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3419;
import net.minecraft.class_344;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_5244;
import net.minecraft.class_6379;
import net.minecraft.class_7172;
import net.minecraft.class_7919;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SoundList extends class_4265<SoundList.SoundEntry> {

    public SoundList(class_310 minecraftClient, int i, int j, int k, int l) {
        super(minecraftClient, i, j, k, l);
        this.field_22744 = false;
    }

    public int addSingleOptionEntry(class_7172<?> option) {
        return this.addSingleOptionEntry(option, true);
    }

    public int addSingleOptionEntry(class_7172<?> option, boolean editable) {
        var entry = SoundEntry.create(this.field_22740.field_1690, this.field_22758, option);
        if (!editable) {
            entry.widgets.forEach(widget -> widget.field_22763 = false);
        }
        return this.method_25321(entry);
    }

    public int addOptionEntry(class_7172<?> firstOption, @Nullable class_7172<?> secondOption) {
        return this.method_25321(SoundEntry.createDouble(this.field_22740.field_1690, this.field_22758, firstOption, secondOption));
    }

    public void addAll(class_7172<?>[] options) {
        for (int i = 0; i < options.length; i += 2) {
            this.addOptionEntry(options[i], i < options.length - 1 ? options[i + 1] : null);
        }
    }

    public int addCategory(class_3419 cat) {
        return this.addSingleOptionEntry(this.createCustomizedOption(cat));
    }

    public int addReadOnlyCategory(class_3419 cat) {
        return this.addSingleOptionEntry(this.createCustomizedOption(cat), false);
    }

    public int addDoubleCategory(class_3419 first, @Nullable class_3419 second) {
        return this.addOptionEntry(this.createCustomizedOption(first),
                (second != null) ? this.createCustomizedOption(second) : null
        );
    }

    public void addAllCategory(class_3419[] categories) {
        this.addAll(Arrays.stream(categories).map(this::createCustomizedOption).toArray(class_7172[]::new));
    }

    public int addGroup(class_3419 group, class_4185.class_4241 pressAction) {
        return super.method_25321(SoundEntry.createGroup(this.field_22740.field_1690, this.createCustomizedOption(group), this.field_22758, pressAction));
    }

    public int method_25322() {
        return 310;
    }

    private class_7172<?> createCustomizedOption(class_3419 category) {
        final class_7172<Double> simpleOption = this.field_22740.field_1690.method_45578(category);
        if (SoundCategories.TOGGLEABLE_CATS.getOrDefault(category, false)) {
            return class_7172.method_41750(simpleOption.toString(), value -> {
                return class_7919.method_47407(SoundCategories.TOOLTIPS.getOrDefault(category, class_5244.field_39003));
            }, simpleOption.method_41753() > 0, value -> {
                simpleOption.method_41748(value ? 1.0 : 0.0);
            });
        }
        return simpleOption;
    }

    @Environment(EnvType.CLIENT)
    protected static class SoundEntry extends class_4265.class_4266<SoundList.SoundEntry> {
        List<? extends class_339> widgets;

        public SoundEntry(List<? extends class_339> w) {
            widgets = w;
        }

        public static SoundEntry create(class_315 options, int width, class_7172<?> simpleOption) {
            return new SoundEntry(List.of(simpleOption.method_18520(options, width / 2 - 155, 0, 310)));
        }

        public static SoundEntry createDouble(class_315 options, int width, class_7172<?> first, @Nullable class_7172<?> second) {
            List<class_339> widgets = new ArrayList<>();
            widgets.add(first.method_18520(options, width / 2 - 155, 0, 150));
            if (second != null) {
                widgets.add(second.method_18520(options, width / 2 + 5, 0, 150));
            }
            return new SoundEntry(widgets);
        }

        public static SoundEntry createGroup(class_315 options, class_7172<?> group, int width, class_4185.class_4241 pressAction) {
            return new SoundEntry(
                    List.of(
                            group.method_18520(options, width / 2 - 155, 0, 280),
                            new class_344(width / 2 + 135, 0, 20, 20, SoundCategories.SETTINGS_ICON, pressAction)
                    ));
        }

        public List<? extends class_364> method_25396() {
            return this.widgets;
        }

        public List<? extends class_6379> method_37025() {
            return this.widgets;
        }

        @Override
        public void method_25343(class_332 context, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            if (this.widgets.isEmpty()) return;

            int i = 0;
            int j = this.widgets.getFirst().method_46426();

            for (class_339 s : this.widgets) {
                s.method_48229(j + i, this.method_46427() + 2);
                s.method_25394(context, mouseX, mouseY, tickDelta);
                i += s.method_25368() + 10;
            }
        }
    }
}
