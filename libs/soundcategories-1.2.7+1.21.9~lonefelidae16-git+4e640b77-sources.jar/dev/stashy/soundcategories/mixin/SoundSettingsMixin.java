package dev.stashy.soundcategories.mixin;

import dev.stashy.soundcategories.gui.CustomSoundOptionsScreen;
import net.minecraft.class_315;
import net.minecraft.class_429;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_429.class)
public class SoundSettingsMixin {
    @Shadow
    private @Final class_315 settings;

    @Inject(method = "method_19829", at = @At("RETURN"), cancellable = true)
    private void soundcategories$redirectToCustomScreen(CallbackInfoReturnable<class_437> cir) {
        cir.setReturnValue(new CustomSoundOptionsScreen(class_429.class.cast(this), settings));
    }
}
