package dev.stashy.soundcategories.mixin;

import dev.stashy.soundcategories.SoundCategories;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_7172;
import net.minecraft.class_7919;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_315.class)
public abstract class GameOptionsMixin {
    @Unique
    private class_3419 currentCategory = null;

    /**
     * Stores the current SoundCategory in loop.
     */
    @Inject(method = "createSoundVolumeOption", at = @At("HEAD"))
    private void soundcategories$storeCategory(String key, class_3419 soundCategory, CallbackInfoReturnable<class_7172<?>> cir) {
        this.currentCategory = soundCategory;
    }

    /**
     * Modifies a Constant of the default sound volume that exists in {@link SoundCategories#DEFAULT_LEVELS} and matches {@link GameOptionsMixin#currentCategory}.<br>
     * default value is 1.0.
     *
     * @see class_315#method_45576
     * @see class_315#class_315
     */
    @ModifyConstant(method = "createSoundVolumeOption", constant = @Constant(doubleValue = 1.0))
    private double soundcategories$changeDefault(double value) {
        if (this.currentCategory == null) {
            return value;
        }
        return SoundCategories.DEFAULT_LEVELS.getOrDefault(this.currentCategory, (float) value);
    }

    @Redirect(method = "createSoundVolumeOption", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/SimpleOption;emptyTooltip()Lnet/minecraft/client/option/SimpleOption$TooltipFactory;"), require = 0)
    private class_7172.class_7277<?> soundcategories$modifyTooltip(String key, class_3419 category) {
        if (SoundCategories.TOOLTIPS.containsKey(category)) {
            return value -> class_7919.method_47407(SoundCategories.TOOLTIPS.get(category));
        }
        return class_7172.method_42399();
    }
}
