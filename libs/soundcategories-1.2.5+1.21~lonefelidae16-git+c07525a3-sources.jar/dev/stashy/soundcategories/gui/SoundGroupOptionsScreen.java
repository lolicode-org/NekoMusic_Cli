package dev.stashy.soundcategories.gui;

import dev.stashy.soundcategories.SoundCategories;
import java.util.Arrays;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_437;

public class SoundGroupOptionsScreen extends AbstractSoundListedScreen {
    private final class_3419 parentCategory;

    public SoundGroupOptionsScreen(class_437 parent, class_315 gameOptions, class_3419 category) {
        super(parent, gameOptions, class_2561.method_43471("soundCategory." + category.method_14840()));
        parentCategory = category;
    }

    @Override
    protected void method_60325() {

    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return this.list.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        try {
            Objects.requireNonNull(this.list);
        } catch (NullPointerException ex) {
            SoundCategories.LOGGER.error("Error during screen initialization", ex);
            return;
        }

        this.list.addReadOnlyCategory(parentCategory);

        final class_3419[] categories = Arrays.stream(class_3419.values()).filter(it -> {
            return SoundCategories.PARENTS.containsKey(it) && SoundCategories.PARENTS.get(it) == parentCategory;
        }).toArray(class_3419[]::new);
        this.list.addAllCategory(categories);

        this.method_37063(this.list);
    }
}
