package dev.stashy.soundcategories.gui;

import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_437;
import net.minecraft.class_4667;

public abstract class AbstractSoundListedScreen extends class_4667 {
    protected SoundList list;

    public AbstractSoundListedScreen(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    @Override
    protected void method_48640() {
        super.method_48640();
        this.list.method_55445(this.field_22789, this.field_49503.method_57727());
    }

    @Override
    protected void method_25426() {
        this.list = new SoundList(this.field_22787, this.field_22789, this.field_22790 - 64, 32, 25);
        super.method_25426();
    }
}
